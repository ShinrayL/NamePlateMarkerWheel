local _, NPW = ...
-- 注册斜杠命令

function NPW:RegisterSlashCommands()
    SLASH_NAMEPLATEMARKERWHEEL1 = "/npw"
    SlashCmdList["NAMEPLATEMARKERWHEEL"] = function(msg)
        local cmd = string.lower(msg or "")
        if cmd == "test" or cmd == "t" then
            -- 测试命令：在屏幕中央显示轮盘（对自己使用player的GUID）
            local playerGUID = UnitGUID("player")
            local scale = UIParent:GetEffectiveScale()
            local x = (GetScreenWidth() / 2) / scale
            local y = (GetScreenHeight() / 2) / scale
            self:ShowWheel(x, y, playerGUID)

        elseif cmd == "reset" then
            -- 重置配置
            self:ResetConfig()
            print("|cff00ffff[NPW]|r 配置已重置")
        elseif cmd == "tar" then
            -- 使用当前目标的GUID来测试
            if UnitExists("target") then
                local guid = UnitGUID("target")
                local scale = UIParent:GetEffectiveScale()
                local x = (GetScreenWidth() / 2) / scale
                local y = (GetScreenHeight() / 2) / scale
                self:ShowWheel(x, y, guid)
            else
                print("|cff00ffff[NPW]|r 没有目标")
            end
        elseif cmd == "config" or cmd == "c" then
            -- 打开独立配置窗口
            if self.configPanel then
                if self.configPanel:IsShown() then
                    self.configPanel:Hide()
                else
                    self.configPanel:Show()
                end
            else
                print("|cff00ffff[NPW]|r 配置界面尚未初始化，请重载界面")
            end
        elseif cmd == "debug" or cmd == "d" then
            -- 切换调试模式
            self.db.debug = not self.db.debug
            print("|cff00ffff[NPW]|r 调试模式: " .. (self.db.debug and "开启" or "关闭"))
        elseif cmd == "status" or cmd == "s" then
            -- 显示状态
            local namePlates = C_NamePlate.GetNamePlates()
            print("|cff00ffff[NPW]|r 状态:")
            print("  姓名板总数: " .. #namePlates)
            print("  鼠标监听: " .. (self.mouseFrame and self.mouseFrame:IsShown() and "启用" or "禁用"))
            print("  调试模式: " .. (self.db.debug and "开" or "关"))
        elseif cmd == "forcereset" or cmd == "f" then
            -- 完全重置插件状态
            print("|cff00ffff[NPW]|r 完全重置插件...")
            NamePlateMarkerWheelDB = nil
            self.db = self:DeepCopy(self.defaults)
            NamePlateMarkerWheelDB = { profile = self.db }
            print("|cff00ffff[NPW]|r 重置完成，请重载界面 (/reload)")
        elseif cmd == "resetqueue" or cmd == "rq" then
            -- 重置标记队列
            self:ResetMarkQueue()
            print("|cff00ffff[NPW]|r 标记队列已重置 (从1号标记开始)")
        elseif cmd == "queue" or cmd == "q" then
            -- 查看队列状态
            local currentMark = self.state.combatMarkQueue[self.state.combatMarkIndex]
            print("|cff00ffff[NPW]|r 标记队列状态:")
            print("  当前队列位置: " .. self.state.combatMarkIndex .. " (标记 " .. currentMark .. ")")
            print("  战斗中点击将设置标记: " .. currentMark)
        else
            print("|cff00ffff[NPW]|r 命令列表:")
            print("  /npw test - 测试轮盘显示")
            print("  /npw tar - 测试目标展示轮盘")
            print("  /npw reset - 重置配置")
            print("  /npw config - 打开配置")
            print("  /npw debug - 切换调试模式")
            print("  /npw status - 查看状态")
            print("  /npw queue - 查看标记队列状态")
            print("  /npw resetqueue - 重置标记队列")
            print("  /npw forcereset - 完全重置（需重载）")
        end
    end
end